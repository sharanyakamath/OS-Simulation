from django.apps import AppConfig


class WikipagesConfig(AppConfig):
    name = 'wikipages'
